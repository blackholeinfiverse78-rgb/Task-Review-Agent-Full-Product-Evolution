# Parikshak Integration Trace Report

This document records the end-to-end trace lineage for a single task submission propagating through the ecosystem layers.

## Trace Lineage Metadata
* **Ecosystem Trace ID**: `trace-ecosystem-proof-01b47dfada47`
* **Associated Submission ID**: `sub-trace-ec`
* **Authorized Sign-off Governor**: `Akash`

## Sequence Map and Timestamps
1. **Intake Ingested**: Ingested by `EcosystemIntegrator` at `2026-06-30T07:06:41.545983Z`
2. **Escalation Triggered**: Low confidence score (`0.25`) triggered escalation to human review queue.
3. **Governor Override Signature**: Governance mutation sign-off signed by authorized actor `Akash`.
4. **Canonical Event Ledger Commit**: Transaction appended as Event Sequence `2` with Hash `36d7e0395ba1bc7de483d28206ec3507d0521b6864dcaf694a44c42604084329`.
5. **Downstream Dispatch**:
   - **Saarthi Visibility Ledger**: Written to `saarthi_visibility.jsonl`
   - **Niyantran Assignment Ledger**: Written to `niyantran_assignments.jsonl`

*Verified: 2026-06-30T07:06:41.545998Z UTC*
