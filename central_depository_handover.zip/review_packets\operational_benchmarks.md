# Parikshak Operational Benchmarks Report

This report documents measured performance and throughput metrics under live load profiles.

## Throughput Profile
* **Rule Engine Throughput**: 111861.83 reviews/sec (6711709.69 reviews/minute)
* **Sustained Throughput**: 111861.83 reviews/sec
* **Peak Throughput**: 4723.06 reviews/sec (under 100 concurrent workers)

## Concurrency Performance Matrix
| Concurrency Level | Throughput (reviews/sec) | Average Latency (ms) | Min Latency (ms) | Max Latency (ms) | Exceptions Count |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **1 User** | 1374.38 | 0.04 | 0.04 | 0.04 | 0 |
| **10 Users** | 3507.30 | 0.03 | 0.02 | 0.04 | 0 |
| **50 Users** | 4420.05 | 0.03 | 0.02 | 0.12 | 0 |
| **100 Users** | 4723.06 | 0.02 | 0.02 | 0.04 | 0 |

## Latency Characterization
* **Single Review Latency**: 0.009 ms
* **Batch Review Latency**: 0.045 ms (5 reviews processed sequentially)
* **Concurrent Review Average Latency (100 users)**: 0.02 ms

## Boot and Startup Gate Timings
* **Cold Start DB Connection Init**: 185.58 ms
* **Warm Start DB Connection Init**: 2.17 ms
* **Startup Safety Gate Integrity Scan**: 0.68 ms

*Verified: 2026-06-30T07:06:41.053140Z UTC*
