# Sprint Changed File List - Parikshak Production Convergence

The following files were modified to achieve production hardening, pass secured route verification, and prevent platform crashes on Windows terminals.

## 1. [test_candidate_review_pipeline.py](file:///g:/Live%20Task%20Review%20Agent%20-%202/tests/test_candidate_review_pipeline.py)
* **Status**: Modified
* **Changes**:
    * Imported `SecurityConfig` and `UserRole` from `security.middleware`.
    * Generated a valid JWT token with role `Governor` at test initialization.
    * Injected authentication headers (`Authorization: Bearer <token>`) to all client API requests targeting secured routes (`/intake`, `/pending`, `/approve`).
    * Hardened the `cleanup` fixture to delete and recreate the `storage/backups` and `storage/checkpoints` directories, clearing out stale snapshots from other tests.

## 2. [task_graph_engine.py](file:///g:/Live%20Task%20Review%20Agent%20-%202/task_selector/task_graph_engine.py)
* **Status**: Modified
* **Changes**:
    * Replaced the non-ASCII Unicode arrow symbol `→` (`\u2192`) with a CP1252-compatible standard ASCII arrow `->` on lines 156 and 164.
    * This resolves the `UnicodeEncodeError` that crashed the logging utility on standard Windows command shells.
